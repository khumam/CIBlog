<div class="row">
    <div class="col-md-12">
        <div class="card ">
            <div class="card-header ">
                <h5 class="card-title">Grafik Pengunjung</h5>
                <p class="card-category">Selama 7 hari ke belakang</p>
            </div>
            <div class="card-body ">
                <canvas id=chartHours width="400" height="100"></canvas>
            </div>
            <div class="card-footer ">
                <hr>
                <div class="stats">
                    <i class="fa fa-history"></i> Updated <?php echo date('H:i:s, d M Y'); ?>
                </div>
            </div>
        </div>
    </div>
</div>
</div>